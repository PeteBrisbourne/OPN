'use strict';
var aws = require('aws-sdk');
var doc;

var lineReader = require('readline').createInterface({
    input: require('fs').createReadStream('voucher.csv')
});

lineReader.on('line', function (line) {
    set('VoucherCode',line, function(err, data){
        console.log('Error during DynamoDB set:' + err);
        console.log('Data:' + data);
    });
    console.log('Line from file:', line);
});

function set (table, data, callback) {
    if(!table) {
        callback('DynamoDB Table name is not set.', null);
    }

    if(!doc) {
        doc = new aws.DynamoDB.DocumentClient({apiVersion: '2012-08-10'});
    }

    var params = {
        Item: {
            voucherCode: data
        },
        TableName: table
    };

    doc.put(params, function(err, data) {
        if(err) {
            console.log('Error during DynamoDB put:' + err);
        }
        callback(err, data);
    });
}